package com.example.myfirstapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_start);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // UI and Events button
        Button button = findViewById(R.id.buttonUIEvent);
        button.setOnClickListener(v -> {
            Intent intent = new Intent(StartActivity.this, MainActivity.class);
            intent.putExtra("message", "Hello World!");
            startActivity(intent);
        });

        // Location Services button
        Button locationButton = findViewById(R.id.button_location);
        locationButton.setOnClickListener(v -> {
            Intent intent = new Intent(StartActivity.this, LocationServicesActivity.class);
            startActivity(intent);
        });

        // ✅ Firebase ML Kit button (NEW)
        Button mlKitButton = findViewById(R.id.buttonML);
        mlKitButton.setOnClickListener(v -> {
            Intent intent = new Intent(StartActivity.this, MLKitActivity.class);
            startActivity(intent);
        });
    }

    public void requestPermissions() {

        int REQUEST_PERMISSION = 3000;

        String[] permissions = {
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
        };

        ActivityCompat.requestPermissions(this, permissions, REQUEST_PERMISSION);
    }
}