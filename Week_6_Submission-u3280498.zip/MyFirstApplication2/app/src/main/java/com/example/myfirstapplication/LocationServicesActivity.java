package com.example.myfirstapplication;

import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class LocationServicesActivity extends AppCompatActivity {

    private static final String TAG = "LocationActivity";
    LocationRequest locationRequest;
    FusedLocationProviderClient fusedLocationClient;
    LocationCallback locationCallback;
    private double latitude;
    private double longitude;

    private TextView tvlat;
    private TextView tvlng;
    private TextView tvaddr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_location_services);

        tvlat = findViewById(R.id.textViewLatitude);
        tvlng = findViewById(R.id.textViewLongitude);
        tvaddr = findViewById(R.id.textViewAddress);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        createLocationRequestLocationCallback();

        if (requestPermissions()) {
            createLocationServicesClient();
        }
    }

    public boolean requestPermissions() {
        int REQUEST_PERMISSION = 3000;
        String[] permissions = {
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
        };

        boolean grantFinePermission =
                ContextCompat.checkSelfPermission(this, permissions[0]) ==
                        PackageManager.PERMISSION_GRANTED;

        boolean grantCoarsePermission =
                ContextCompat.checkSelfPermission(this, permissions[1]) ==
                        PackageManager.PERMISSION_GRANTED;

        if (!grantFinePermission || !grantCoarsePermission) {
            ActivityCompat.requestPermissions(this, permissions, REQUEST_PERMISSION);
            return false;
        }

        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 3000) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                createLocationServicesClient();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @SuppressLint("MissingPermission")
    public void createLocationServicesClient() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, location -> {
                    if (location != null) {
                        latitude = location.getLatitude();
                        longitude = location.getLongitude();
                        updateLocationUI();
                        showLocationAddress();
                    }
                    startLocationUpdates();
                });
    }

    public void createLocationRequestLocationCallback() {
        locationRequest = new LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY, 5000)
                .setMinUpdateIntervalMillis(2000)
                .build();

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                Location location = locationResult.getLastLocation();
                if (location != null) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                    updateLocationUI();
                    showLocationAddress();
                }
            }
        };
    }

    private void updateLocationUI() {
        tvlat.setText("Latitude: " + latitude);
        tvlng.setText("Longitude: " + longitude);
    }

    public void showLocationAddress() {
        if (!Geocoder.isPresent()) {
            tvaddr.setText("Address: Geocoder not available");
            return;
        }

        tvaddr.setText("Address: Loading...");

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        
        // Use the modern async API for API 33+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            geocoder.getFromLocation(latitude, longitude, 1, new Geocoder.GeocodeListener() {
                @Override
                public void onGeocode(@NonNull List<Address> addresses) {
                    displayAddress(addresses);
                }

                @Override
                public void onError(String errorMessage) {
                    runOnUiThread(() -> tvaddr.setText("Address error: " + errorMessage));
                }
            });
        } else {
            // Fallback for older versions
            new Thread(() -> {
                try {
                    List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
                    displayAddress(addresses);
                } catch (IOException e) {
                    runOnUiThread(() -> tvaddr.setText("Address: Service unavailable"));
                    Log.e(TAG, "Geocoder failed", e);
                }
            }).start();
        }
    }

    private void displayAddress(List<Address> addresses) {
        String addressResult;
        if (addresses != null && !addresses.isEmpty()) {
            StringBuilder sb = new StringBuilder("Address:\n");
            Address addr = addresses.get(0);
            for (int i = 0; i <= addr.getMaxAddressLineIndex(); i++) {
                sb.append(addr.getAddressLine(i)).append("\n");
            }
            addressResult = sb.toString();
        } else {
            addressResult = "Address: No address found";
        }

        runOnUiThread(() -> tvaddr.setText(addressResult));
    }

    @SuppressLint("MissingPermission")
    public void startLocationUpdates() {
        if (fusedLocationClient != null) {
            fusedLocationClient.requestLocationUpdates(
                    locationRequest,
                    locationCallback,
                    Looper.getMainLooper());
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (fusedLocationClient != null) {
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }
    }
}
